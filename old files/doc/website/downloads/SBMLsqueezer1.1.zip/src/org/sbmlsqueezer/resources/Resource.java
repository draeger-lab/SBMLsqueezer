package org.sbmlsqueezer.resources;

/**
 * Dummy class that just loads resource files if required.
 * Created at 2009-02-05.
 * @author Hannes Borch
 * @author Andreas Dr&auml;ger <a
 *         href="mailto:andreas.draeger@uni-tuebingen.de">
 *         andreas.draeger@uni-tuebingen.de</a>
 * 
 */
public class Resource {

}
